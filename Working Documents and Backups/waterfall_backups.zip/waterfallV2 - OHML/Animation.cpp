#include "constants.h"

struct Pulse {
  CHSV **ani;
  int len;
};


class Animation {
  protected:
    int run_amount;
  public:
    bool
      isDone() {return run_amount == 0;};
    virtual CHSV* getNext() = 0;
    virtual CHSV* getStop() = 0;
    virtual void reset() = 0;
};

class Waterfall: public Animation {};

class OHML: public Animation{
  
  private:
  
    int
      pos,
      len;
    CHSV
      fg,
      bg,
      strip[64][5];
    
    Pulse* pulse_maker(Pulse *pulse, CHSV base_colour, CHSV target_colour, CHSV fade_speed) {
      uint8_t hue_steps = ceil(abs((target_colour.hue - base_colour.hue) / fade_speed.hue));
      uint8_t sat_steps = ceil(abs((target_colour.sat - base_colour.sat) / fade_speed.sat));
      uint8_t val_steps = ceil(abs((target_colour.val - base_colour.val) / fade_speed.val));
      pulse->len = 2 * max(hue_steps, max(sat_steps, val_steps)) - 1;
    
      return pulse;
    }
      
  public:
  
    void printRow(int pos = 0) {
      Serial.print("Row ");
      Serial.print(pos);
      Serial.print(":\t");
      Serial.print(strip[pos][0].hue);
      Serial.print("\t");
      Serial.print(strip[pos][1].hue);
      Serial.print("\t");
      Serial.print(strip[pos][2].hue);
      Serial.print("\t");
      Serial.print(strip[pos][3].hue);
      Serial.print("\t");
      Serial.println(strip[pos][4].hue);
    }
    
    OHML(CHSV base, CHSV background, int num_runs = 0){
      fg = base;
      bg = background;
      run_amount = num_runs;
      len = 64;
      pos = len - 1;

      CHSV temp_array[len][STRIP_AMOUNT] {
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //O
        {bg, fg, fg, fg, bg},
        {fg, fg, bg, fg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, fg, bg, fg, fg},
        {bg, fg, fg, fg, bg},

        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //H
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, fg, fg, fg, fg},
        {fg, fg, fg, fg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},

        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
      
        //M
        {fg, bg, bg, bg, fg},
        {fg, fg, bg, fg, fg},
        {fg, fg, fg, fg, fg},
        {fg, bg, fg, bg, fg},
        {fg, bg, fg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
     
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //L
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, fg, fg, fg, fg},
        {fg, fg, fg, fg, fg},
      
        //space
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg}
      };

      // this line causes compile time to go from 6 seconds to over 80 seconds
      memcpy(strip, temp_array, sizeof(CHSV) * len * STRIP_AMOUNT);
    }

    CHSV* getNext() {
      if (pos == 0) {
        pos = len;
        if (run_amount > 0) {
          --run_amount;
          return strip[--pos];
        } else{
          printRow(pos - 1);
          return NULL;
        }
      } else {
        printRow(pos - 1);
        return strip[--pos];
      }
    }
    
    CHSV* getStop() {
      return getNext();
    }
    
    void reset() {
      pos = 0;
    }

    int test() {
      return strip[8][1].hue;
    }
};
