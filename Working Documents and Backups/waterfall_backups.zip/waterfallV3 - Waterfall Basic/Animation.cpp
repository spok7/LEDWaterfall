#include "constants.h"

struct Pulse {
  CHSV *ani;
  uint8_t len;
};


class Animation {
  protected:
//    int run_amount;
  public:
//    bool
//      isDone() {return run_amount == 0;};
    virtual CHSV* getNext() = 0;
    virtual CHSV* getStop() = 0;
};

class Waterfall: public Animation {
  private:

    int pos;

    CHSV *current_colours;
    int *random_amount;

    Pulse *highlight, *shimmer;

    void print_col(int row, Pulse *pulse) {
      Serial.print("Row (");
      delay(20);
      Serial.print(row);
      delay(20);
      Serial.print("/");
      delay(20);
      Serial.print(pulse->len - 1);
      delay(20);
      Serial.print("):\t");
      delay(20);
      Serial.print(pulse->ani[row].hue);
      delay(20);
      Serial.print("\t");
      delay(20);
      Serial.print(pulse->ani[row].sat);
      delay(20);
      Serial.print("\t");
      delay(20);
      Serial.println(pulse->ani[row].val);
      delay(20);
    }

    void pulse_maker(Pulse *pulse, CHSV base_colour, CHSV target_colour, CHSV fade_rate, bool reverse_fade_rate) {
      
      if (fade_rate.hue == 0) fade_rate.hue == 1;
      if (fade_rate.sat == 0) fade_rate.sat == 1;
      if (fade_rate.val == 0) fade_rate.val == 1;
      
      uint8_t hue_steps = ceil(abs((float) (target_colour.hue - base_colour.hue) / fade_rate.hue));
      uint8_t sat_steps = ceil(abs((float) (target_colour.sat - base_colour.sat) / fade_rate.sat));
      uint8_t val_steps = ceil(abs((float) (target_colour.val - base_colour.val) / fade_rate.val));

      pulse->len = 2 * max(hue_steps, max(sat_steps, val_steps)) + 1;
      pulse->ani = new CHSV[pulse->len];


      int fill;
      CHSV new_target;
      if (not reverse_fade_rate) {
        fill = 0;
        pulse->ani[fill] = base_colour;
        new_target = target_colour;
      } else {
        fill = (pulse->len - 1) / 2;
        pulse->ani[fill] = target_colour;
        new_target = base_colour;
      }

       while (pulse->ani[fill].hue != new_target.hue || pulse->ani[fill].sat != new_target.sat || pulse->ani[fill].val != new_target.val) {

        ++fill;
        
        pulse->ani[fill] = pulse->ani[fill - 1];

        if (pulse->ani[fill].hue == new_target.hue) {
          // do nothing
        } else if (abs(pulse->ani[fill].hue - new_target.hue) < fade_rate.hue){
          pulse->ani[fill].hue = new_target.hue;
        } else if (pulse->ani[fill].hue < new_target.hue) {
          pulse->ani[fill].hue += fade_rate.hue;
        } else {
          pulse->ani[fill].hue -= fade_rate.hue;
        }
      
        if (pulse->ani[fill].sat == new_target.sat) {
          // do nothing
        } else if (abs(pulse->ani[fill].sat - new_target.sat) < fade_rate.sat){
          pulse->ani[fill].sat = new_target.sat;
        } else if (pulse->ani[fill].sat < new_target.sat) {
          pulse->ani[fill].sat += fade_rate.sat;
        } else {
          pulse->ani[fill].sat -= fade_rate.sat;
        }
      
        if (pulse->ani[fill].val == new_target.val) {
          // do nothing
        } else if (abs(pulse->ani[fill].val - new_target.val) < fade_rate.val){
          pulse->ani[fill].val = new_target.val;
        } else if (pulse->ani[fill].val < new_target.val) {
          pulse->ani[fill].val += fade_rate.val;
        } else {
          pulse->ani[fill].val -= fade_rate.val;
        }
      }

      for (int i = 0; i < (pulse->len - 1) / 2; ++i) {
        if (not reverse_fade_rate) {
          pulse->ani[pulse->len - 1 - i] = pulse->ani[i];
        } else {
          pulse->ani[i] = pulse->ani[pulse->len - 1 - i];
        }
      }
    }

  public:

    Waterfall(CHSV base_col, CHSV highlight_col, CHSV shimmer_col, CHSV highlight_rate, CHSV shimmer_rate, bool highlight_reversed, bool shimmer_reversed, int repeat_low_bound, int repeat_high_bound) {

      highlight = new Pulse();
      shimmer = new Pulse();
      current_colours = new CHSV[5];
      pos = 0;

      pulse_maker(highlight, base_col, highlight_col, highlight_rate, highlight_reversed);
      pulse_maker(shimmer, base_col, shimmer_col, shimmer_rate, shimmer_reversed);
      for (int i = 0; i < shimmer->len; ++i) {
        print_col(i, shimmer);
      }
    }

    CHSV* getNext() {
      if (pos == shimmer->len - 1) {
        pos = 0;
      }
      for (int i = 0; i < STRIP_AMOUNT; ++i) {
        current_colours[i] = shimmer->ani[pos];
      }
      ++pos;
      return current_colours;
    }

    CHSV* getStop() {
      return getNext();
    }
    
};



class OHML: public Animation{
  
  private:
  
    int
      run_amount,
      pos,
      len;
    CHSV
      fg,
      bg,
      strip[64][5];
      
  public:
  
    void printRow(int pos = 0) {
      Serial.print("Row ");
      Serial.print(pos);
      Serial.print(":\t");
      Serial.print(strip[pos][0].hue);
      Serial.print("\t");
      Serial.print(strip[pos][1].hue);
      Serial.print("\t");
      Serial.print(strip[pos][2].hue);
      Serial.print("\t");
      Serial.print(strip[pos][3].hue);
      Serial.print("\t");
      Serial.println(strip[pos][4].hue);
    }
    
    OHML(CHSV base, CHSV background, int num_runs = 0){
      fg = base;
      bg = background;
      run_amount = num_runs;
      len = 64;
      pos = len - 1;

      CHSV temp_array[len][STRIP_AMOUNT] {
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //O
        {bg, fg, fg, fg, bg},
        {fg, fg, bg, fg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, fg, bg, fg, fg},
        {bg, fg, fg, fg, bg},

        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //H
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, fg, fg, fg, fg},
        {fg, fg, fg, fg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},

        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
      
        //M
        {fg, bg, bg, bg, fg},
        {fg, fg, bg, fg, fg},
        {fg, fg, fg, fg, fg},
        {fg, bg, fg, bg, fg},
        {fg, bg, fg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
        {fg, bg, bg, bg, fg},
     
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},

        //L
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, bg, bg, bg, bg},
        {fg, fg, fg, fg, fg},
        {fg, fg, fg, fg, fg},
      
        //space
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg},
        {bg, bg, bg, bg, bg}
      };

      memcpy(strip, temp_array, sizeof(CHSV) * len * STRIP_AMOUNT);
    }

    CHSV* getNext() {
      if (pos == 0) {
        pos = len;
        if (run_amount > 0) {
          --run_amount;
          return strip[--pos];
        } else{
          printRow(pos - 1);
          return NULL;
        }
      } else {
        printRow(pos - 1);
        return strip[--pos];
      }
    }
    
    CHSV* getStop() {
      return getNext();
    }
    
    void reset() {
      pos = 0;
    }

    int test() {
      return strip[8][1].hue;
    }
};
